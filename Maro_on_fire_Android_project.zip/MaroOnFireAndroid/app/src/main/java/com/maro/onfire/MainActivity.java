package com.maro.onfire;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 901;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 48, 32, 32);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xff16040a);
        TextView title = new TextView(this);
        title.setText("Maro on fire 🔥"); title.setTextColor(0xffff3344); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView info = new TextView(this);
        info.setText("اضغط السماح بالظهور فوق التطبيقات، ثم افتح Sporcle Party واضغط إظهار القائمة من إشعار Maro on fire.");
        info.setTextColor(0xffffffff); info.setTextSize(16); info.setPadding(0, 24, 0, 24);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));
        Button start = new Button(this); start.setText("السماح وإظهار القائمة");
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQUEST_OVERLAY);
            } else startOverlay();
        });
        setContentView(root);
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) startOverlay();
    }
    private void startOverlay() {
        Intent i = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        finish();
    }
}
