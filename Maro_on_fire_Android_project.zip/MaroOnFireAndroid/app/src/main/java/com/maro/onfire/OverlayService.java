package com.maro.onfire;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class OverlayService extends Service {
    private WindowManager wm; private WebView web;
    private static final String CHANNEL = "maro_overlay";
    @Override public void onCreate() { super.onCreate(); createNotification(); showOverlay(); }
    private void createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Maro on fire overlay", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
        Intent stop = new Intent(this, OverlayService.class).setAction("STOP");
        PendingIntent pi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Maro on fire").setContentText("القائمة العائمة نشطة").setOngoing(true).addAction(android.R.drawable.ic_menu_close_clear_cancel, "إغلاق القائمة", pi);
        startForeground(7, b.build());
    }
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent != null && "STOP".equals(intent.getAction())) stopSelf();
        return START_NOT_STICKY;
    }
    private void showOverlay() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        web = new WebView(this); web.setBackgroundColor(0x00000000);
        web.getSettings().setJavaScriptEnabled(true); web.setWebChromeClient(new WebChromeClient()); web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Object() { @JavascriptInterface public void close() { stopSelf(); } }, "MaroOverlay");
        web.loadUrl("file:///android_asset/menu.html");
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels * .94), WindowManager.LayoutParams.WRAP_CONTENT, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL; p.y = (int)(getResources().getDisplayMetrics().density * 44);
        wm.addView(web, p);
    }
    @Override public void onDestroy() { if (wm != null && web != null) { try { wm.removeView(web); } catch (Exception ignored) {} } if (web != null) web.destroy(); stopForeground(true); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
